var app = getApp();
var userInfo = app.globalData.userInfo;

Page({
  data: {
    userInfo: userInfo,
  },
})