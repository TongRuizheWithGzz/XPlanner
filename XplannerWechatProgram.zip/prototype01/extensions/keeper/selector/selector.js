var food = require("../../../data/food");
var food_type = require("../../../data/food_type");

Page({
  data: {
    food: food,
    food_type: food_type,
    location: "地址",
    choosen_type_id: 0,
  },
  onLoad: function(options) {
    var self = this;
    wx.getLocation({
      success: function(res) {
        self.setData({
          location: "(" + res.latitude + "," + res.longitude + ")"
        })
      },
    })
  },

  changeSelectedType: function(e) {
    console.log(e.currentTarget.dataset.id);
    this.setData({
      choosen_type_id: e.currentTarget.dataset.id,
    })
  }
})