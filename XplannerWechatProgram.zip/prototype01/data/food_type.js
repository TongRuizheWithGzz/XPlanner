var food_type = [{
  food_type_id: 0,
  food_type_name: "水果",
}, {
  food_type_id: 1,
  food_type_name: "面条",
}, {
  food_type_id: 2,
  food_type_name: "米饭",
}, {
  food_type_id: 3,
  food_type_name: "西餐",
}, {
  food_type_id: 4,
  food_type_name: "小吃",
}, {
  food_type_id: 5,
  food_type_name: "糕点",
}, ];

module.exports = food_type;