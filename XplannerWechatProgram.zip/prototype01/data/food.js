var food = [
  {
    food_id: 0,
    food_name: '苹果',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 0,
  }, {
    food_id: 1,
    food_name: '泡面',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 1,
  }, {
    food_id: 2,
    food_name: '橘子',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 0,
  }, {
    food_id: 3,
    food_name: '香蕉',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 0,
  }, {
    food_id: 4,
    food_name: '咖喱饭',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 2,
  }, {
    food_id: 5,
    food_name: '牛排',
    calorie: 20,
    dininghall: '第一餐厅',
    food_type_id: 3,
  }
];

module.exports = food;