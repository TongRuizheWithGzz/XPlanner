var user_food_eaten = [{
  user_foot_eaten_id: 0,
  user_id: 0,
  food_name: "shit",
  calorie: 10,
  ate_time: "2016.1.1 20:00"
}, {
  user_foot_eaten_id: 1,
  user_id: 0,
  food_name: "shit",
  calorie: 10,
  ate_time: "2016.1.1 20:00"
}, {
  user_foot_eaten_id: 2,
  user_id: 0,
  food_name: "shit",
  calorie: 10,
  ate_time: "2016.1.1 20:00"
}, {
  user_foot_eaten_id: 3,
  user_id: 0,
  food_name: "shit",
  calorie: 10,
  ate_time: "2016.1.1 20:00"
}, {
  user_foot_eaten_id: 4,
  user_id: 0,
  food_name: "shit",
  calorie: 10,
  ate_time: "2016.1.1 20:00"
}, ]

module.exports = user_food_eaten;