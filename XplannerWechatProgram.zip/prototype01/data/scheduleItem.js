var scheduleItem = [{
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, {
  title: "Run",
  start_time: "2016.6.21",
  end_time: "2016.6.22",
  description: "Run",
  address: "The second eatery",
  user_id: 1
}, ];

module.exports = scheduleItem;