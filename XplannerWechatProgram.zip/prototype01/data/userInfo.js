var userInfo = {
  id: 0,
  name: "shit",
  avatar: "/icons/timg.jpg"
}

module.exports = userInfo;